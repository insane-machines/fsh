class DataError(Exception):
    pass
class MatchError(Exception):
    pass
class ProcessError(Exception):
    pass
